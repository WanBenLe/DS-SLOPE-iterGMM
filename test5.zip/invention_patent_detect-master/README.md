# invention_patent_detect

# 功能

1.传入基于产品标题和描述

2.预测Top5的CPC分类

3.并召回最相似的Top n发明专利信息

# 数据

数据的pickle文件在以下路径:

\\190.168.1.31\app\数据_AI_PYTHON\Eric\发明专利pickle

数据已经传入milvus,地址为47.115.159.129:15930-default/invention_patent_detect



# 部署

git clone代码后按照上述内容修改配置文件(模型.数据相关路径配置可维持默认)


```
cd invention_patent_detect

# 创建环境

conda create -n invention_patent_detect python=3.8.10

conda activate invention_patent_detect

# 请确保当前目录在invention_patent_detect下,ls可以看到APP文件夹等
pip install -r ./APP/data/requirements.txt

bash ./APP/start_service.sh

```
日志文件有两个
invention_patent_detect_nohup.log
和
invention_patent_detect.log

# 输入输出
测试文件在./APP/test/__init__.py中

地址:

PROJECT_IP:PROJECT_PORT/product/detect(项目ip:项目端口/product/detect)

给定一个json形式的产品title和description,返回预测CPC,潜在侵权专利号和欧氏距离的三个list

输入:
```
{title : str, description : str, top_n : int}

# e.g

{"title" : "this is a apple",   "description" : "this apple is red", "top_n" : 100}

```


输出:
```
{"message" : str,
"code" : bool,
"data" : {'CPC' : list[str], 'wo_number' : list[str], 'cossim':list[float]},
"cost_time" : float}

# e.g

'{"cost_time":144.3138551712036,
"code":true,
"data":{"cpc":["C12N","A23EX","A23L","A01K","A01EX"],
"wo_number":["USPP25671""USPP19909","USPP33495"],
"cossim":[0.668342649936676,0.6631386876106262,0.6329033374786377]},
"message":"Be carefull:\\n        For now, this api only support English. And the title_num and title_length don\'t work!!!!! \\n        "}\n'
```

# 配置文件修改

invention_patent_detect/APP/src/conf.py

PROJECT_IP.PROJECT_PORT:接口的ip地址和端口

LABEL2IDX_PATH:分类号转换的json

DEBERTA_MODEL_PATH:分类模型的预训练模型架构

DEBERTA_MODEL_BIN_PATH:finetune后的参数路径

SBERT_MODEL_PATHS:模型文件夹

SBERT_ONNX_GPU_NAME:CUDA优化后的ONNX路径

SBERT_ONNX_CPU_NAME:CPU优化后的ONNX路径

MILVUS_IP:MILVUS的IP地址

MILVUS_PORT:MILVUS的端口

MILVUS_CONNECT:MILVUS的connect

MILVUS_COLLECTION:MILVUS中发明专利数据的存储集合


# 注意点:


1.文本向量化模型需要基于特定硬件进行优化,目前仅提供了基于CPU优化的部分

2.

召回方式

要求数据如下存储,且milvus支持标量匹配

假设wo_number:US000001有CPC分类['A01','A02']

(此处要求每条只有一个分类)

id:自增数据,wo_number:'US000001',CPC:'A01',embedding:384维数组

id:自增数据,wo_number:'US000001',CPC:'A02',embedding:384维数组

即每个分类冗余存储1条

milvus做召回时对于每个CPC分类前过滤混合检索召回Top n(默认为100)*5,结果合并后去重,再召回Top n为最终结果

劣势:需要约5倍硬盘容量

优势:可以使用CPC分类进行分区,检索的时候可以只读取分区内容进内存,召回结果与模型建立时一致
