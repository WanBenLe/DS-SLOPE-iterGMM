# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     main.py
   Description :
   Author :       slwan
   date：          2023/7/24
-------------------------------------------------
   Change Activity: 2023/11/15:
-------------------------------------------------
"""
__author__ = 'slwan'

import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

import time
import json
import traceback

from flask_cors import CORS
from flask import Flask, request
from flask_restx import Api, Resource

from APP.src.conf import LOGGER, PROJECT_IP, PROJECT_PORT, Globle
from APP.src import model_init
# from APP.src.utils.update_model import load_model
from APP.src.utils import send_message_to_dingding
from APP.src.swagger_models import SwaggerModels
from APP.src.register_service import register_service
from gevent.pywsgi import WSGIServer

app = Flask(__name__)
CORS(app)
api = Api(app, doc='/doc/')
swagger_models = SwaggerModels(api)
model_class = model_init()


@api.route("/product/detect")
class Product(Resource):
    def _get_product_data(self, myrequest):
        data = myrequest.get_json()
        title = data['title']
        description = data['description']
        top_n = int(data['top_n'])
        if top_n > 5000:
            top_n = 5000
        elif top_n < 1:
            top_n=1
        return title, description, top_n

    @api.expect(swagger_models.single_product_input_model)
    @api.marshal_with(swagger_models.single_product_output_model)
    def post(self):
        continued = True
        msg = ["""Be carefull:
        For now, this api only support English.Require 1=<top_n<=5000.
        """]
        begin = time.time()

        try:
            # 新项目 修改输入
            title, description = self._get_product_data(request)
        except Exception as e:
            continued = False
            products = []
            emsg = "Geting data from request failed! Check your data!\n"
            emsg += traceback.format_exc()
            LOGGER.error(emsg)
            msg.append(emsg)

        try:
            if continued:
                result, emsg = model_class.detect_product(title, description, top_n)
            else:
                result = False
        except Exception as e:
            continued = False
            result = {}
            emsg = json.dumps({"INPUT products": products}) + "\n"
            emsg += "\n" + traceback.format_exc()
            LOGGER.error(f"{emsg}")
            msg.append(emsg)
        end = time.time()
        return {"message": "\n".join(msg),
                "code": continued,
                "data": result,
                "cost_time": end - begin}


if __name__ == '__main__':
    send_message_to_dingding("Begin！")
    http_server = WSGIServer((PROJECT_IP, PROJECT_PORT), app)
    http_server.serve_forever()

    # 1. 发送dingding通知程序开始工作

    # 2. 发送通知进行程序注册
    # register_service()
    # 3. 开启服务
    #
    # app.run(host=PROJECT_IP, port=PROJECT_PORT)
    LOGGER.info('invention_patent_detect begin!')
