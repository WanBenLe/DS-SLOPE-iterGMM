import time

# pip install pymilvus==2.2.8
from pymilvus import (connections, utility, FieldSchema, CollectionSchema, DataType, Collection)

# from pymilvus import db
import random
from pickle import load, dump
import numpy as np
import os
# from minio import Minio  # pip3 install minio
from tqdm import tqdm
from numba import jit
import pandas as pd
import requests
import requests
import json
import re

con1 = re.compile('true')

url = "https://smartai.suntekcorps.com/invention-patent-detect/product/detect"

headers = {
    'Content-Type': 'application/json'
}


connections.disconnect('default')
connections.connect("default", host="10.168.203.4", port="19530")

new_collection = Collection("invention_patent_detect")
new_collection.load()

d1 = pd.read_csv('完整数据.csv', encoding='ansi')
names = d1['pd_name'].values
clalles = d1[['c1', 'c2', 'c3', 'c4', 'c5']].fillna('').values
numbers = d1['专利号'].values
#desc=d1['title'].values
results = np.zeros((len(names), 5), dtype=object)
results[:, 0] = d1['被投诉产品ID'].values
for i in range(len(names)):
    print(i)
    try :
        int(numbers[i][-2])
    except:
        numbers[i]=numbers[i][:-2]
        print(numbers[i])
    query = new_collection.query(
        expr="wo_number in [\"" + numbers[i] + "\"]",
        offset=0,
        limit=10,
        output_fields=["wo_number"],
    )
    if len(query) < 1:
        # 数据库都不在搞个X
        print('g1')
        continue
    else:
        results[i, 1] = 1
    payload = json.dumps({
        "title": "\"" + names[i] + "\"",
        "description": ""#"\"" + desc[i] + "\""
    })
    response = requests.request("POST", url, headers=headers, data=payload)
    print(response.text)
    res = eval(re.sub(con1, 'True', response.text))['data']

    cls = clalles[i]
    cls = cls[cls != '']
    cla_pred = res['cpc']
    for cl in cla_pred:
        if cl in cls:
            results[i, 2] = 1
            break
    if results[i, 2] == 0:
        # 还是得分类预测对
        print('g2')

    wo = np.array(res['wo_number'])
    indx = np.argwhere(wo == numbers[i])
    if len(indx) > 0:
        results[i, 3] = 1
        results[i, 4] = indx[0][0] + 1
    else:
        print('g3')
        print(1)
r1 = results[results[:, 1] == 1]
print('入库率', np.round(len(r1) / len(results), 4) * 100, '%')
print(len(r1))
r2 = r1[r1[:, 2] == 1]
print('入库中分类准确率', np.round(len(r2) / len(r1), 4) * 100, '%')
r3 = r1[r1[:, 3] == 1]
print('入库中召回率', np.round(len(r3) / len(r1), 4) * 100, '%')
print('分类准确中召回率', np.round(len(r3) / len(r2), 4) * 100, '%')
pd.DataFrame(results,columns=['id','ruku','fenlei','zhaohui1','rank']).to_csv('zhaohui.csv')
print(1)
