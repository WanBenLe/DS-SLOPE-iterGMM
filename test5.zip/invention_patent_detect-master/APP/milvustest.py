import time

# pip install pymilvus==2.2.8
from pymilvus import (connections, utility, FieldSchema, CollectionSchema, DataType, Collection)

# from pymilvus import db
import random
from pickle import load, dump
import numpy as np
import os
# from minio import Minio  # pip3 install minio
from tqdm import tqdm
from numba import jit

#connections.connect("default", host="10.168.203.4", port="19530")

'''
print(utility.has_collection("invention_patent_detect"))
#删除invention_patent_detect,别用,数据会全部删掉
utility.drop_collection("invention_patent_detect")
print(utility.has_collection("invention_patent_detect"))
# 查看分区名字
print('partitions', collection.partitions)
# milvus_batch_insert(collection=collection, file_name='182')
print('collection index,', collection.indexes)
'''
print(1)
'''

def Minio_insert(path, name):
    client = Minio("0.0.0.0:9000", access_key="minioadmin", secret_key="minioadmin", secure=False)
    bucket = "a-bucket"
    if not client.bucket_exists(bucket):
        client.make_bucket(bucket)
    try:
        res = client.fput_object(bucket_name=bucket, object_name=name, file_path=path,
                                 part_size=10 * 1024 * 1024, num_parallel_uploads=3)

        print(res.object_name)
    except Exception as err:
        print(err)


def milvus_batch_insert(collection, file_name='182'):
    now_path = os.getcwd() + '/'
    col1 = 'wo_number.npy'
    col2 = 'embedding.npy'
    col3 = 'CPC.npy'
    pkl_tmp = load(open(file_name + '.pkl', 'rb'))
    np.save(col1, np.array(pkl_tmp[0]))
    np.save(col2, np.array(pkl_tmp[1], dtype=np.dtype('float32', len(pkl_tmp))))
    np.save(col3, np.array(pkl_tmp[2]))
    Minio_insert(now_path + col1, col1)
    Minio_insert(now_path + col2, col2)
    Minio_insert(now_path + col3, col3)

    # 分区不能超过4096,所以再次插入得重写
    collection.create_partition(file_name)

    task_id = utility.do_bulk_insert(collection_name="CPCdata", partition_name=file_name, files=[col1, col2, col3])
    task = utility.get_bulk_insert_state(task_id=task_id)
    while task.state not in [1, 6]:
        time.sleep(5)
        task = utility.get_bulk_insert_state(task_id=task_id)
        print(task)
    if task.state == 1:
        print('Failed!',task.failed_reason)
    collection.flush()
    os.remove("wo_number.npy")
    os.remove("embedding.npy")
    os.remove("CPC.npy")
    
    


'''
# 链接,默认数据库.ip和port

'''
#2.2.8没有database这玩意
try:
    # 新建一个库
    database = db.create_database("cpc_search")
except:
    db.using_database("cpc_search")
    if utility.has_collection('CPCdata'):
        utility.drop_collection('CPCdata')
    db.drop_database("cpc_search")
    database = db.create_database("cpc_search")
# 修改默认库
db.using_database("cpc_search")
# 打印有什么库
print(db.list_database())
# 先传数据,再建索引
print(1)
# https://milvus.io/docs/schema.md
'''


@jit(parallel=True)
def L2Norm(embedding):
    for i in range(len(embedding)):
        embedding[i] = embedding[i] / np.linalg.norm(embedding[i], 2)
    return embedding

'''
if utility.has_collection("invention_patent_detect"):

    collection = Collection("invention_patent_detect")
    print('load invention_patent_detect')
else:
    print('create invention_patent_detect')
    id_field = FieldSchema(name="id", dtype=DataType.INT64, description="id", is_primary=True, auto_id=True)
    wo_number_field = FieldSchema(name="wo_number", dtype=DataType.VARCHAR, max_length=30)
    embedding_field = FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=384, description="vector")
    # position_field = FieldSchema(name="CPC", dtype=DataType.VARCHAR, max_length=30)

    schema = CollectionSchema(fields=[id_field, wo_number_field, embedding_field, position_field], auto_id=True,
                              enable_dynamic_field=True,
                              description="invention_patent_detect datas")

    schema = CollectionSchema(fields=[id_field, wo_number_field, embedding_field], auto_id=True,
                              enable_dynamic_field=True,
                              description="invention_patent_detect datas")
    collection = Collection(name='invention_patent_detect', schema=schema)
    # L2就是L2,IP是内积,向量索引
'''
'''
x_num = 0
# 一次插入inputs_n条
inputs_n = 3500
for pkl_num in tqdm(range(183)):
    print(str(pkl_num+0))
    data = load(open('//190.168.1.31/app\数据_AI_PYTHON\Eric\发明专利pickle/' + str(pkl_num+0) + '.pkl', 'rb'))
    data[1] = L2Norm(np.array(data[1])).tolist()
    lenx = len(data[0])
    # 数据按照每个CPC分类一条拆开
    all_datas = []
    for i in range(lenx):
        wo_number = data[0][i]
        embedding = data[1][i]
        cpc_list = data[2][i].split(',')
        for j, classes in enumerate(cpc_list):
            all_datas.append([wo_number, embedding, classes[:-1]])
    all_datas = np.array(all_datas)
    x_num += len(all_datas)
    print('拆分后数据量,', len(all_datas), '总数据量', x_num)
    classes_all = np.unique(all_datas[:, -1])
    # 然后根据不同分类插入不同分区
    for class_ in classes_all:
        # 检查有没有CPC分类创建分区,没有就跳过
        if not collection.has_partition(class_):
            collection.create_partition(class_)
            print('分区创建', class_)
        data_tmp = all_datas[all_datas[:, -1] == class_]
        batch = len(data_tmp) // inputs_n + 1
        for i in range(batch):
            if i != batch - 1:
                d1 = data_tmp[inputs_n * i:inputs_n * (i + 1)]
            else:
                d1 = data_tmp[inputs_n * i:]
            if len(d1)==0:
                continue
            data_insert = [d1[:, 0].tolist(), d1[:, 1].tolist()]
            try:
                collection.insert(data_insert, partition_name=class_)
            except Exception as e:
                print(1)
collection.flush()                
'''

"""
# 虚构需要创建的数据
ndata = 20000
data = [
    [str(i) + 'a' for i in range(ndata)],
    [[random.random() for _ in range(384)] for _ in range(ndata)],
    [str(i % 10) for i in range(ndata)]
]
"""

'''
try:
    collection.release()
    collection.drop_index(index_name='_default_idx_102')
    collection.drop_index(index_name='scalar_index')
except:
    pass
collection = Collection("invention_patent_detect")
print('collection index,', collection.indexes)

index_params = {
    'field_name': "embedding",
    "metric_type": "IP",
    "index_type": "IVF_PQ",
    "params": {"nlist": 10000,'m':96}
}
print('collection index,', collection.indexes)
# 向量索引
collection.create_index(field_name="embedding", index_params=index_params)
print(utility.index_building_progress("invention_patent_detect"))
collection.flush()
'''

# collection.load()
try:
    connections.disconnect('default')
except:
    pass
connections.connect("default", host="10.168.203.4", port="19530")

new_collection = Collection("invention_patent_detect")
try:
    new_collection.release()
except:
    pass
new_collection.load()


class_ = 'A21'
rand1 = [random.random() for _ in range(384)]
r1 = [rand1]
print(r1)
search_param = {
    "data": r1,
    "anns_field": "embedding",
    "param": {"metric_type": "IP", "params": {"nlist": 10000, 'nprobe': 128}, "offset": 0},
    "offset": 0,
    "limit": 100,
    "expr": '',
    'partition_names':[class_],
    "output_fields": ['wo_number']
}
res = new_collection.search(**search_param)

result = []
for i in range(len(res)):
    tmp = res[i]
    for j in range(len(tmp)):
        result.append([tmp[j].entity._row_data['wo_number'], tmp[j].distance,class_])
print(utility.index_building_progress("invention_patent_detect"))
print(result)
print(1)