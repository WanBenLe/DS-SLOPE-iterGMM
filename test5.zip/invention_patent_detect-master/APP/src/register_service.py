# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     register_service
   Description :
   Author :       slwan
   date：          2023/7/27
-------------------------------------------------

"""
__author__ = 'slwan'
import requests
from APP.src.conf import PROJECT_PORT, PROJECT_NAME, REGISTER_SERVICE_URL


def register_service():
    """
    注册监控这个程序
    """
    requests.post(REGISTER_SERVICE_URL, json={"port": PROJECT_PORT, "project_name": PROJECT_NAME})
