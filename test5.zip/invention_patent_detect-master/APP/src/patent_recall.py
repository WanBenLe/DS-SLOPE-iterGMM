# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     patent_recall
   Description :
   Author :       slwan
   date：          2023/7/24
-------------------------------------------------
   Change Activity: 2023/11/15:
-------------------------------------------------
"""
__author__ = 'slwan'

import gc
import json
import os

import numpy as np
import onnxruntime
import pandas as pd
import psutil
import torch
from pymilvus import (connections, utility, FieldSchema, CollectionSchema, DataType, Collection)  # , db)
from sentence_transformers import SentenceTransformer
from sentence_transformers.models import Pooling
from src.conf import LOGGER, MILVUS_IP, MILVUS_PORT, MILVUS_CONNECT, MILVUS_COLLECTION, \
    SBERT_MODEL_PATH, SBERT_ONNX_GPU_NAME, SBERT_ONNX_CPU_NAME  # , MILVUS_DATABASE
from tqdm import tqdm
from transformers import AutoConfig, AutoModel, AutoTokenizer


def tokenizer_data(data, tokenizer):
    # 将数据转成onnx需要的dict,需要ONNX支持动态输入
    input_ids = np.zeros((len(data), 256), dtype=int)
    token_type_ids = np.zeros((len(data), 256), dtype=int)
    attention_mask = np.zeros((len(data), 256), dtype=int)
    for i in range(len(data)):
        tokens = list(tokenizer(data[i], padding='max_length', truncation=True, max_length=256,
                                return_tensors="np").data.values())
        input_ids[i, :] = tokens[0]
        token_type_ids[i, :] = tokens[1]
        attention_mask[i, :] = tokens[2]
    return {'input_ids': input_ids, 'token_type_ids': token_type_ids, 'attention_mask': attention_mask}


def load_all_model(path):
    # 从modules.json读取模型路径
    modules_json_path = os.path.join(path, 'modules.json')
    with open(modules_json_path) as fIn:
        modules_config = json.load(fIn)
    from_s_path = os.path.join(path, modules_config[0].get('path'))
    from_pooling_path = os.path.join(path, modules_config[1].get('path'))
    return from_s_path, from_pooling_path


class MilvusSearch:
    def __init__(self):
        # 这里是CUDA优化的onnx模型,后续得优化了再用
        from_s_path, from_pooling_path = load_all_model(SBERT_MODEL_PATH)
        # 读sbert
        config_class, model_class, tokenizer_class = AutoConfig, AutoModel, AutoTokenizer
        s_config = config_class.from_pretrained(from_s_path)
        self.tokenizer = tokenizer_class.from_pretrained(from_s_path, do_lower_case=True)
        use_cuda = torch.cuda.is_available()  # 检测是否有可用的gpu
        self.device = torch.device("cuda:0" if use_cuda else "cpu")
        if use_cuda:
            export_model_path = SBERT_MODEL_PATH + SBERT_ONNX_GPU_NAME
            sess_options = onnxruntime.SessionOptions()
            self.session = onnxruntime.InferenceSession(export_model_path, sess_options,
                                                        providers=['CUDAExecutionProvider'])
        else:
            export_model_path = SBERT_MODEL_PATH + SBERT_ONNX_CPU_NAME
            sess_options = onnxruntime.SessionOptions()
            self.session = onnxruntime.InferenceSession(export_model_path, sess_options,
                                                        providers=['CPUExecutionProvider'])
        self.pooling_model = Pooling.load(from_pooling_path).to(self.device)
        self.top_n = 1000
        LOGGER.info('embedding model load!')
        # 读取完整的new_collection

        '''
        try:
            connections.disconnect('default')
        except:
            pass
        '''
        try:
            connections.connect("default", host=MILVUS_IP, port=MILVUS_PORT)
        except:
            LOGGER.info("没有连接")
            pass
        self.new_collection = Collection("invention_patent_detect")
        mem = psutil.virtual_memory()
        available_mem = mem.available / (1024 * 1024 * 1024)
        LOGGER.info("可用内存大小：%.2f GB" % available_mem)
        try:
            self.new_collection.load()
        except:
            LOGGER.info("数据没有读取进内存")
            pass

    def milvus_query(self, embedding: list, classes: list, top_n=1000):
        try:
            classes = classes.tolist()
        except:
            pass
        result = []
        search_param = {
            "data": embedding,
            "anns_field": "embedding",
            "param": {"metric_type": "IP", "params": {"nlist": 5000, 'nprobe': 128}, "offset": 0},
            "offset": 0,
            "limit": int(top_n * 2),  # 此处提供2倍冗余防止重复之后数量太少
            "expr": '',
            'partition_names': classes,
            "output_fields": ['wo_number']
        }
        res = self.new_collection.search(**search_param)
        for i in range(len(res)):
            tmp = res[i]
            for j in range(len(tmp)):
                result.append([tmp[j].entity._row_data['wo_number'], tmp[j].distance])

        df = pd.DataFrame(np.array(result), columns=['wo_number', 'cos_sim'])
        result = df.sort_values(['cos_sim'], ascending=False).drop_duplicates(subset=['wo_number']).values[:top_n]
        return result

    def search_type1(self, title: str, descrp: str, classes: list, top_n: int):
        # 第一种是CPC分类的每类召回top_n,去重后取top_n
        inputs = tokenizer_data([title + ' ' + descrp], self.tokenizer)
        ort_inputs = dict(inputs)
        ort_outputs = self.session.run(None, ort_inputs)
        embedding = self.pooling_model.forward(
            features={'token_embeddings': torch.Tensor(ort_outputs[0]).to(self.device), 'attention_mask': torch.Tensor(
                ort_inputs.get('attention_mask')).to(self.device)})['sentence_embedding'].cpu().numpy()
        embedding = embedding / np.linalg.norm(embedding, 2)
        LOGGER.info('type1 query' + title + ' ' + descrp)
        result = self.milvus_query(embedding, classes, top_n)
        return result

    '''
    def search_type2(self, title: str, descrp: str, classes: list):
        # 第二种是全量召回type2_num(默认为top_n*5),去重后取top_n
        inputs = tokenizer_data([title + ' ' + descrp], self.tokenizer)
        ort_inputs = dict(inputs)
        ort_outputs = self.session.run(None, ort_inputs)
        embedding = self.pooling_model.forward(features={'token_embeddings': torch.Tensor(ort_outputs[0]).
                                               to(self.device), 'attention_mask': torch.Tensor(
            ort_inputs.get('attention_mask')).
                                               to(self.device)})['sentence_embedding'].cpu().numpy()
        LOGGER('type2 query', title + ' ' + descrp)
        result = milvus_query(embedding, classes, search_type=2, top_n=100)
        result_all = np.array((len(result), 2), dtype=object)
        result_all[:, 0] = ''
        for i in range(result):
            # 要求目标分类在才留下来
            for cls in classes:
                if cls in result[i][2]:
                    result_all[i, :] = result[i][:, 2]
        result_all = result_all[result_all[:, 0] != '']
        result = pd.DataFrame(result_all, columns=['wo_number', 'L2']).drop_duplicates(subset=['wo_number']). \
                     sort_values('L2').values[:self.top_n]
        return result
    '''

