# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     conf
   Author :        slwan
   date：          2023/7/23
   Description :
-------------------------------------------------
   Change Activity:
                   2023/9/14:
-------------------------------------------------
"""
from __future__ import absolute_import, print_function

__author__ = 'slwan'

import os
import logging.config
from pyhocon import ConfigFactory
from dingtalkchatbot.chatbot import DingtalkChatbot


########################################
# 基础的
########################################
def find_app_dir(path):
    """ find APP dir
      APP dir, likes: /home/chen/PycharmProjects/ExampleCode/APP
    """
    if path:
        head, tail = os.path.split(path)
        if tail == 'APP':
            return path
        else:
            return find_app_dir(head)
    else:
        raise Exception("No found 'APP_DIR'！")


APP_DIR = find_app_dir(os.path.abspath(__file__))
DATA_DIR = os.path.join(APP_DIR, 'data')

#############################################################
####    configuration
#############################################################
configure_file = os.path.join(DATA_DIR, "conf/configure.conf")
conf = ConfigFactory.parse_file(configure_file)

#############################################################
#####   写日志模块
#############################################################
logging_file = os.path.join(DATA_DIR, "conf/logger.ini")
logging.config.fileConfig(logging_file)
LOGGER = logging.getLogger("out2file")


########################################
# 服务自动部署相关公共变量
########################################
class Globle:
    Update_Model_Queue = None


# 项目的ip和端口
PROJECT_IP = '0.0.0.0'
PROJECT_PORT = 18890

# 新项目 后续会使用到env_name 和 project_name，必须确保它们要具备高辨识度，不能重名。
ENV_NAME = "invention_patent_detect"
PROJECT_NAME = "invention_patent_detect"
REGISTER_SERVICE_URL = PROJECT_IP + str(PROJECT_PORT) + "/register"


# 初始化机器人小丁
_webhook = 'https://oapi.dingtalk.com/robot/send?access_token=f982f70c611b146f5e4ece5802cbcf3532a631c270fdf92795bbfdc38e3e1d84'
_secret = 'SEC43a5354f19fde54d6a24858edced42862bba3acb1db53a21c929298fed7c18ae'
MOUDEGANQING_DAGONGREN = DingtalkChatbot(_webhook, secret=_secret)  # 方式二：勾选“加签”选项时使用（v1.5以上新功能）
AT_MOBILES = [18925491419, ]

#stop_words的csv
STOPWORDS_PATH='./APP/data/stopwords.csv'
# 分类号转换的json
LABEL2IDX_PATH = './APP/data/label2idx.json'
# 分类模型的预训练模型架构和finetune后的参数路径

DEBERTA_MODEL_PATH = './APP/model/deberta/'
DEBERTA_MODEL_BIN_PATH = './APP/model/deberta/bert640932.pth'
'''
DEBERTA_MODEL_PATH = './APP/model/deberta_small/'
DEBERTA_MODEL_BIN_PATH = './APP/model/deberta_small/deberta-v3-small_best0.pth'
'''
# ST的模型文件夹和CUDA优化后的ONNX路径
SBERT_MODEL_PATH = './APP/model/model11_all-MiniLM-L6-v2/'
SBERT_ONNX_GPU_NAME = 'patent_all-MiniLM-L6-v2_cuda.onnx'
SBERT_ONNX_CPU_NAME = 'patent_all-MiniLM-L6-v2_cpu.onnx'
# MILVUS的IP.端口,connect,还有数据库和存的集合
MILVUS_IP = '10.168.203.4'
MILVUS_PORT = '19530'
MILVUS_CONNECT = 'default'
#MILVUS_DATABASE = 'CPCdata'
MILVUS_COLLECTION = 'invention_patent_detect'

# ########################################
# # mongodb
# ########################################
# pymongo_conn_mapping = conf.get("pymongeo_connection_information")
# DATAGROUP_USERNAME = pymongo_conn_mapping['username']
# DATAGROUP_PASSWD = pymongo_conn_mapping['passwd']
# DATAGROUP_HOST = pymongo_conn_mapping['host']
# DATAGROUP_PORT = pymongo_conn_mapping['port']
# DATAGROUP_DB = pymongo_conn_mapping['db']
# DATAGROUP_DOCUMENT = pymongo_conn_mapping['document']
#
#
# ########################################
# # stopwords and phrases
# ########################################
# _stopword_file = os.path.join(DATA_DIR, "en_stopwords.txt")
# with open(_stopword_file) as f:
#     STOPWORDS = set([w.strip().lower() for w in f if w.strip()])
#
# _phrase_file = os.path.join(DATA_DIR, "phrase.txt")
# with open(_phrase_file) as f:
#     PHRASES = set([w.strip().lower() for w in f if w.strip()])
#
#
# #############################################################
# ## 公共变量
# #############################################################
# OCCASION_TOPN = 30
# OCCASION_FLAG = "occasion"
#

# ########################################
# # 模型
# ########################################
# Text_Classifier_Filename = os.path.join(DATA_DIR, "predict_model.gz")
#
#
# ########################################
# ## cluster model
# ########################################
# WORD_CLUSTER_MAPPING_FILENAME = os.path.join(DATA_DIR, "product_word324632_cluster2000_2021104.json")
# TFIDF_WORD_FILENAME = os.path.join(DATA_DIR, "selected_L1_words.npy")
# WORD_IDF_FILENAME = os.path.join(DATA_DIR, "selected_L1_words_idf.npy")
#
#
# ########################################
# ## sentence model
# ########################################
# SENTENCE_TFIDF_MODEL_FILENAME = os.path.join(DATA_DIR, "sen2vec_tfidf_model.gz")
# SENTENCE_WORD_VECTORS_FILENAME = os.path.join(DATA_DIR, "word324632_vectors.npy")
# SENTENCE_WORD_FILENAME = os.path.join(DATA_DIR, "word324632_words.npy")
#
#
# ########################################
# ## istore sql
# ########################################
# istore_conn_mapping = conf.get("istore_connection_information")
# ISTORE_HOST = istore_conn_mapping['host']
# ISTORE_PORT = istore_conn_mapping['port']
# ISTORE_USER = istore_conn_mapping['username']
# ISTORE_PASSWD = istore_conn_mapping['passwd']
# ISTORE_DB = istore_conn_mapping['db']
#
# data_analysis_conn_mapping = conf.get("data_analysis_connection_information")
# DATA_ANALYSIS_HOST = data_analysis_conn_mapping['host']
# DATA_ANALYSIS_PORT = data_analysis_conn_mapping['port']
# DATA_ANALYSIS_USER = data_analysis_conn_mapping['username']
# DATA_ANALYSIS_PASSWD = data_analysis_conn_mapping['passwd']
# DATA_ANALYSIS_DB = data_analysis_conn_mapping['db']
#
#
# #########################################
# ##   tmp file
# #########################################
# TMP_NEW_DATA_FILE = os.path.join(DATA_DIR, "tmp_new_data_file.tmp")
#
#
# ########################################
# #   GLOBAL VAR
# ########################################
# DATE_FORMAT = "%Y-%m-%d"
# PROFIT = "profit"
# SALE = "sale"
