# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     __init__.py
   Description :
   Author :       slwan
   date：          2023/09/14
-------------------------------------------------
"""
__author__ = 'slwan'

import requests
from conf import LOGGER, PROJECT_IP, PROJECT_PORT

url = "http://" + str(PROJECT_IP) + ":" + str(PROJECT_PORT) + "/product/detect"
# 表单数据格式，参数 data ，数据都是字典去保存
data = {"title": "this is a apple ", "description": " this is a apple. this is a boy"}
r_login = requests.post(url=url, json=data)
LOGGER.info(r_login.text)
print(r_login.text)
