# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     swagger_models
   Description :
   Author :       zfchen
   date：          2022/5/1
-------------------------------------------------
   Change Activity: 2022/11/15:
-------------------------------------------------
"""
__author__ = 'slwan'
from flask_restx import fields


class SwaggerModels:
    # TODO:新项目 请修改为你自己需要输入输出
    def __init__(self, api):
        self._api = api
        """
        注意：如果你不会写这个示例，请去阅读官方文档：
              https://flask-restplus.readthedocs.io/en/stable/swagger.html

        """
        ##################################################################
        self.single_product_input_model = self._api.model(
            "single_product_input_model",
            {
                "title": fields.String("1Set Solar Water Air Pump Quiet 3 Working Modes for Fish Tank Garden Pool",
                                       description="产品标题"),
                "description": fields.String("""Description:
                Mini And Portable--The Solar Powered Water Air Pump is a pocket size and lightweight, very convenient to carry and use.""",
                description="产品描述"),
                "top_n": fields.Integer(min=1),
            }
        )
        
        
        
        
        ##################################################################
        
        self._single_product_output_model = self._api.model(
            "_single_product_output_model",
            {
                "cpc": fields.List(fields.String),
                "wo_number": fields.List(fields.String),
                "cossim": fields.List(fields.Float)
            }
        )

        
        self.single_product_output_model = self._api.model(
            "single_product_output_model",
            {
                "cost_time": fields.Float(description="接口耗时"),
                "code": fields.Boolean(description="程序是否出错"),
                "data": fields.Nested(self._single_product_output_model),
                "message": fields.String(description="报错信息")
            }
        )
       
        
        
        
        '''
        
        
        self._single_product_output_model = self._api.model(
            "single_product_output_model",
            {
                "title": fields.String("1Set Solar Water Air Pump Quiet 3 Working Modes for Fish Tank Garden Pool",
                                       description="产品标题"),
                "description": fields.String("""Description:
                Mini And Portable--The Solar Powered Water Air Pump is a pocket size and lightweight, very convenient to carry and use.""",
                description="产品描述"),
            }
        )
        
        
        
        self.products_input_model = self._api.model(
            "products_input_model",
            {"products": fields.List(fields.Nested(self._single_product_input_model))}
        )

        ##################################################################
        self._trademark_output_model = self._api.model(
            "trademark_output_model",
            {
                "trademark": fields.String,
                "goods_and_sevice": fields.List(fields.String)
            }
        )
        


        self.products_output_model = self._api.model(
            "products_output_model",
            {
                "cost_time": fields.Float(description="接口耗时"),
                "code": fields.Boolean(description="程序是否出错"),
                "data": fields.List(fields.Nested(self._product_output_model), description="返回值"),
                "message": fields.String(description="报错信息")
            }
        )
        '''
