# -*- coding: utf-8 -*-
# @Time    : 2023/07/27
# @Author  : wanshanle
# @File    : utils.py
# @Software: PyCharm
# @Description: 
import time
from src.conf import MOUDEGANQING_DAGONGREN,AT_MOBILES,PROJECT_NAME



class TimePointer:
    def __init__(self):
        self._lis = [("begin", time.time())]

    def append(self, name):
        self._lis.append((name, time.time()))
        print(f"#{len(self._lis) - 1:<3}Costime(s):{self._lis[-1][1] - self._lis[-2][1]:<8.2f}{name}\t")

    def combine(self):
        lis = self._lis
        all_lis = ["==========================="]
        for i in range(1, len(lis)):
            name, pnt = lis[i]
            all_lis.append(f"#{i:<3}Costime(s):{pnt - lis[i - 1][1]:.2f} \t{name}")
        all_lis.append(f"#Total#: {lis[-1][1] - lis[0][1]:<.2f}s")
        all_lis.append("===========================")
        info = "\n".join(all_lis)
        return info

###########################################################################################
# 钉钉
###########################################################################################
def send_message_to_dingding(msg):
    MOUDEGANQING_DAGONGREN.send_text(msg=PROJECT_NAME+'\n'+msg, at_mobiles=AT_MOBILES)


