# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     __init__.py
   Description :
   Author :       slwan
   date：          2023/7/24
-------------------------------------------------
   Change Activity: 2023/11/15:
-------------------------------------------------
"""
__author__ = 'slwan'

import json
import traceback

from .cpc_classifier import CpcClassifier
from .patent_recall import MilvusSearch


###############################################################################

class model_init():
    def __init__(self):
        self.cpc_classifier = CpcClassifier()
        self.patent_recall = MilvusSearch()

    def detect_product(self, title: str, descrp: str):
        try:
            # 获取top5分类,listi返回
            classes = self.cpc_classifier.predict(title, descrp)
            result = self.patent_recall.search_type1(title, descrp, classes, top_n)
            result = {'cpc': classes, "wo_number": result[:, 0].tolist(), "cossim": result[:, 1].tolist()}
            error_msg = ""
        except Exception as e:
            error_msg = json.dumps({"title": title, "descrp": descrp, "error_msg": traceback.format_exception()})
            result = {'CPC': [], "wo_number": [], "cossim": []}

        return result, error_msg
